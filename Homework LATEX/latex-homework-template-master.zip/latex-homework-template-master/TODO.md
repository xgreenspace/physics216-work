# TODO

- Possibly incorporate some of these things: http://tex.stackexchange.com/questions/31183/class-file-for-homework-assignments
